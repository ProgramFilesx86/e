curl -s https://someserver.io/setup.sh | bash
